name = "aiowiki"
from .wiki import *
from .exceptions import *
