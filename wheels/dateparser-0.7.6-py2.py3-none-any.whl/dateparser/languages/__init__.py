# -*- coding: utf-8 -*-
from .locale import Locale
from .loader import default_loader
